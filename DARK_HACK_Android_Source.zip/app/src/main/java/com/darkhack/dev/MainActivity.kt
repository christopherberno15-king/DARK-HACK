package com.darkhack.dev

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 8, 17)
    private val panel = Color.rgb(19, 17, 30)
    private val purple = Color.rgb(183, 123, 255)
    private val green = Color.rgb(124, 255, 178)
    private val muted = Color.rgb(160, 151, 180)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showDashboard()
    }

    private fun baseColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(18), dp(18), dp(24))
        setBackgroundColor(bg)
    }

    private fun showDashboard() {
        val scroll = ScrollView(this)
        content = baseColumn()
        scroll.addView(content)
        setContentView(scroll)

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "DH"
            textSize = 23f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(87, 39, 143), 14)
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }
        brandRow.addView(logo)
        val brandText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        brandText.addView(text("DARK HACK", 21f, Color.WHITE, true))
        brandText.addView(text("ANDROID DEVELOPMENT LAB", 9f, purple, true))
        brandRow.addView(brandText)
        content.addView(brandRow)
        content.addView(space(24))

        val status = text("●  LOCAL SANDBOX  •  VERSION 0.1.0", 10f, green, true)
        content.addView(status)
        content.addView(space(12))
        content.addView(text("BUILD IN THE", 30f, Color.WHITE, true))
        content.addView(text("SHADOWS.", 32f, purple, true))
        content.addView(space(8))
        content.addView(text("Òganize modil, ekri kòd, epi teste pwojè jwèt ou gen otorizasyon pou modifye.", 14f, muted, false))
        content.addView(space(20))

        val create = button("＋  CREATE MODULE") {
            Toast.makeText(this, "Module Studio pare pou yon pwochen etap.", Toast.LENGTH_SHORT).show()
        }
        content.addView(create)
        content.addView(space(10))
        content.addView(sectionCard("WORKSPACE OVERVIEW", "Starter Android natif natal", "Dashboard lokal • Pa bezwen koneksyon pou ouvri"))
        content.addView(space(12))
        content.addView(sectionCard("GAME EXPLORER", "Unity Test Scene", "Pwofil demonstrasyon sèlman; pa gen koneksyon jwèt verifye."))
        content.addView(space(12))
        content.addView(sectionCard("MODULE STUDIO", "Modil demonstrasyon", "Kreye epi jere modil nan vèsyon ki vin apre yo."))
        content.addView(space(12))
        content.addView(sectionCard("CODE EDITOR", "Local code workspace", "Pa egzekite kòd sou lòt aplikasyon oswa jwèt."))
        content.addView(space(12))
        content.addView(sectionCard("TEST LAB", "Sandbox protection active", "Pa gen okenn aksè otomatik sou jwèt ekstèn."))
        content.addView(space(20))
        content.addView(text("DARK HACK  •  ANDROID STARTER  •  2026", 9f, muted, true))
    }

    private fun sectionCard(title: String, headline: String, detail: String): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(16))
            background = rounded(panel, 14, Color.rgb(48, 39, 66))
        }
        card.addView(text(title, 10f, purple, true))
        card.addView(space(8))
        card.addView(text(headline, 17f, Color.WHITE, true))
        card.addView(space(5))
        card.addView(text(detail, 12f, muted, false))
        return card
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        setTextColor(Color.WHITE)
        isAllCaps = false
        background = rounded(Color.rgb(126, 61, 218), 12)
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setOnClickListener { action() }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setLineSpacing(dp(3).toFloat(), 1f)
        }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
