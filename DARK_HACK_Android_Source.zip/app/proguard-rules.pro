# Starter app: no custom ProGuard rules.
