# DARK HACK Android (native starter)

This is a native Android Kotlin starter project for DARK HACK.

## Build APK with GitHub Actions
1. Create a new GitHub repository (for example `dark-hack-android`).
2. Upload the contents of this folder to the repository root (including the `.github` folder).
3. Open the repository's **Actions** tab.
4. Select **Build DARK HACK APK** and click **Run workflow**, or push to the `main` branch.
5. When the workflow succeeds, open its run and download the `DARK-HACK-debug-apk` artifact.
6. Unzip the artifact; it contains `app-debug.apk`. Transfer it to your Android phone and tap it to install. Android may ask you to allow installs from the app you used to open the file; only enable that for a trusted source and turn it off afterwards.

## Build locally
Requirements: JDK 17, Android SDK platform 35, Gradle 8.9+.
From this folder run:
```bash
gradle assembleDebug
```
APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## What this version is
A minimal native Android app with a DARK HACK branded dashboard, local sandbox status, and demo sections.

## Important limitations
This is source code prepared for a remote build. An APK has NOT been compiled or verified in this environment. The starter does not yet include online accounts, a cloud database, real game integrations, or external game modification. Game profiles are demonstrative only.
